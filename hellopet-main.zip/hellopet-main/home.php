<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="stylehome.css">
</head>
<body>

	<div class="container">
		<div class="header">
			<h1>Hello Pet</h1>
		</div>

		<div class="navbar">
				<li><a href="home.php" class="active">Home</a></li>
				<li><a href="packages.php">Packages</a></li>
				<li><a href="about.php">About Us</a></li>
				<li><a href="contact.php">Contact Us</a></li>
		</div>
	</div>
</body>
</html>>